import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Play, Film } from 'lucide-react';
import { movieApi } from '../services/movieApi';
import VideoPlayerComponent from '../components/VideoPlayer';

const VideoPlayer = () => {
  const { id, title } = useParams();
  const navigate = useNavigate();
  const [movie, setMovie] = useState(null);
  const [videoData, setVideoData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showPlayer, setShowPlayer] = useState(false);

  useEffect(() => {
    const fetchMovieAndVideo = async () => {
      if (!id) return;

      try {
        setLoading(true);
        setError(null);
        
        console.log('🎬 Loading movie details...');
        
        // Fetch movie details
        const movieResponse = await movieApi.getMovieDetails(id);
        setMovie(movieResponse);

        // Get video content for this movie
        if (movieResponse) {
          console.log(`🎥 Getting trailer for: "${movieResponse.title}"`);
          
          const videoResult = movieApi.getMovieVideo(movieResponse.title, movieResponse.id);
          setVideoData(videoResult);
          
          console.log('✅ Trailer content ready!');
        }
      } catch (error) {
        console.error('❌ Error loading content:', error);
        setError('Failed to load content');
      } finally {
        setLoading(false);
      }
    };

    fetchMovieAndVideo();
  }, [id]);

  // Update document title
  useEffect(() => {
    if (movie) {
      document.title = `${movie.title} - CineStream`;
    }
    return () => {
      document.title = 'CineStream';
    };
  }, [movie]);

  const handleBackClick = () => {
    // Navigate back to movie details page with proper URL structure
    const urlTitle = movie?.title?.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || title;
    navigate(`/movie/${id}/${urlTitle}`);
  };

  const startPlayer = () => {
    setShowPlayer(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-500 mx-auto mb-4"></div>
          <div className="text-white text-xl">Loading trailer...</div>
          <div className="text-gray-400 text-sm mt-2">Preparing your movie experience...</div>
        </div>
      </div>
    );
  }

  if (error || !movie) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-500 text-xl mb-4">{error || 'Content not found'}</div>
          <button 
            onClick={() => navigate('/')}
            className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg transition-colors"
          >
            Go to Home
          </button>
        </div>
      </div>
    );
  }

  // If we should show the player, render the video player
  if (videoData?.success && showPlayer) {
    return (
      <div className="bg-black min-h-screen fixed inset-0 z-[9999]">
        <VideoPlayerComponent 
          src={videoData.videoUrl} 
          title={videoData.title} 
          movieId={movie.id}
        />
      </div>
    );
  }

  return (
    <div className="bg-black min-h-screen">
      {/* Header with Back Button */}
      <div className="absolute top-0 left-0 right-0 z-50 bg-gradient-to-b from-black/80 to-transparent">
        <div className="flex items-center justify-between p-6">
          <button
            onClick={handleBackClick}
            className="flex items-center space-x-2 text-white hover:text-red-400 transition-all group bg-black/50 backdrop-blur-sm rounded-lg px-4 py-2 border border-gray-600 hover:border-red-500"
          >
            <ArrowLeft className="h-5 w-5 group-hover:-translate-x-1 transition-transform" />
            <span>Back to Movie</span>
          </button>

          <div className="text-center">
            <h1 className="text-white text-xl font-semibold">{movie.title}</h1>
            {videoData?.success && (
              <p className="text-gray-300 text-sm">Official Trailer</p>
            )}
          </div>

          <div className="w-32"></div> {/* Spacer for centering */}
        </div>
      </div>

      {/* Video Content */}
      <div className="flex items-center justify-center min-h-screen pt-20 pb-8">
        {videoData?.success ? (
          <div className="w-full max-w-4xl mx-auto px-4">
            {/* Status Indicator */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center space-x-2 bg-green-900/30 border border-green-500/30 rounded-lg px-4 py-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-green-400 font-medium">✅ Trailer Ready</span>
              </div>
            </div>

            {/* Video Preview Card */}
            <div className="bg-gray-900/50 border border-gray-700 rounded-lg overflow-hidden shadow-2xl">
              {/* Thumbnail */}
              <div className="relative group cursor-pointer" onClick={startPlayer}>
                <img
                  src={videoData.thumbnail}
                  alt={videoData.title}
                  className="w-full h-64 md:h-80 object-cover transition-transform group-hover:scale-105"
                />
                
                {/* Play Overlay */}
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/60 transition-all">
                  <div className="bg-red-600 hover:bg-red-700 rounded-full p-6 transform group-hover:scale-110 transition-all shadow-lg">
                    <Play className="h-12 w-12 text-white fill-current ml-1" />
                  </div>
                </div>

                {/* Video Badge */}
                <div className="absolute top-4 right-4 bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-medium flex items-center space-x-1">
                  <Film className="h-4 w-4" />
                  <span>Official Trailer</span>
                </div>
              </div>

              {/* Video Info */}
              <div className="p-6">
                <h2 className="text-white text-xl font-semibold mb-2">{videoData.title}</h2>
                <p className="text-gray-400 text-sm mb-6">{videoData.description}</p>
                
                {/* Action Button */}
                <button
                  onClick={startPlayer}
                  className="w-full flex items-center justify-center space-x-2 bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg transition-all transform hover:scale-105 font-semibold"
                >
                  <Play className="h-5 w-5 fill-current" />
                  <span>Watch Trailer</span>
                </button>
              </div>
            </div>

            {/* Additional Info */}
            <div className="mt-6 text-center">
              <p className="text-gray-500 text-sm">
                Full-featured video player with controls, seeking, volume adjustment, and fullscreen support.
              </p>
            </div>
          </div>
        ) : (
          <div className="text-center max-w-md mx-auto px-4">
            {/* No Content Found */}
            <div className="bg-gray-900/50 border border-gray-700 rounded-lg p-8">
              <div className="text-6xl mb-4">🎬</div>
              <h2 className="text-white text-xl font-semibold mb-4">Trailer Loading...</h2>
              <p className="text-gray-400 mb-6">
                Preparing trailer content for "{movie.title}".
              </p>
              
              <button
                onClick={handleBackClick}
                className="w-full bg-gray-700 hover:bg-gray-600 text-white px-6 py-3 rounded-lg transition-colors"
              >
                Back to Movie Details
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default VideoPlayer;