const API_KEY = '1890ed6b';
const BASE_URL = 'https://www.omdbapi.com';

export const movieApi = {
  // Search for movies by title
  async searchMovies(query) {
    try {
      const response = await fetch(`${BASE_URL}/?s=${encodeURIComponent(query)}&apikey=${API_KEY}`);
      const data = await response.json();
      
      if (data.Response === 'True') {
        return {
          results: data.Search.map((movie) => ({
            id: movie.imdbID,
            title: movie.Title,
            overview: '', // OMDb doesn't provide plot in search results
            poster_path: movie.Poster !== 'N/A' ? movie.Poster : null,
            backdrop_path: movie.Poster !== 'N/A' ? movie.Poster : null,
            release_date: movie.Year,
            vote_average: 0, // Will be fetched in details
            vote_count: 0
          }))
        };
      }
      return { results: [] };
    } catch (error) {
      console.error('Error searching movies:', error);
      return { results: [] };
    }
  },

  // Get popular movies (we'll use a predefined list of popular movie IDs)
  async getPopular() {
    const popularMovieIds = [
      'tt0111161', // The Shawshank Redemption
      'tt0068646', // The Godfather
      'tt0468569', // The Dark Knight
      'tt0071562', // The Godfather Part II
      'tt0050083', // 12 Angry Men
      'tt0108052', // Schindler's List
      'tt0167260', // The Lord of the Rings: The Return of the King
      'tt0110912', // Pulp Fiction
      'tt0060196', // The Good, the Bad and the Ugly
      'tt0137523'  // Fight Club
    ];

    const movies = [];
    for (const id of popularMovieIds) {
      try {
        const movie = await this.getMovieDetails(id);
        if (movie) {
          movies.push(movie);
        }
      } catch (error) {
        console.error(`Error fetching movie ${id}:`, error);
      }
    }

    return {
      results: movies
    };
  },

  // Get trending movies (we'll use another set of popular recent movies)
  async getTrending() {
    const trendingMovieIds = [
      'tt6751668', // Parasite
      'tt7286456', // Joker
      'tt4154756', // Avengers: Endgame
      'tt1825683', // Black Panther
      'tt3896198', // Guardians of the Galaxy Vol. 2
      'tt2250912', // Spider-Man: Homecoming
      'tt3501632', // Thor: Ragnarok
      'tt1211837', // Doctor Strange
      'tt3498820', // Captain America: Civil War
      'tt2395427'  // Avengers: Age of Ultron
    ];

    const movies = [];
    for (const id of trendingMovieIds) {
      try {
        const movie = await this.getMovieDetails(id);
        if (movie) {
          movies.push(movie);
        }
      } catch (error) {
        console.error(`Error fetching movie ${id}:`, error);
      }
    }

    return {
      results: movies
    };
  },

  // Get detailed movie information
  async getMovieDetails(id) {
    try {
      const response = await fetch(`${BASE_URL}/?i=${id}&apikey=${API_KEY}&plot=full`);
      const data = await response.json();
      
      if (data.Response === 'True') {
        return {
          id: data.imdbID,
          title: data.Title,
          overview: data.Plot !== 'N/A' ? data.Plot : 'No plot available.',
          poster_path: data.Poster !== 'N/A' ? data.Poster : null,
          backdrop_path: data.Poster !== 'N/A' ? data.Poster : null,
          release_date: data.Released !== 'N/A' ? data.Released : data.Year,
          vote_average: data.imdbRating !== 'N/A' ? parseFloat(data.imdbRating) : 0,
          vote_count: data.imdbVotes !== 'N/A' ? parseInt(data.imdbVotes.replace(/,/g, '')) : 0,
          runtime: data.Runtime !== 'N/A' ? parseInt(data.Runtime.replace(' min', '')) : null,
          genres: data.Genre !== 'N/A' ? data.Genre.split(', ').map((name, index) => ({
            id: index,
            name: name
          })) : [],
          director: data.Director !== 'N/A' ? data.Director : null,
          actors: data.Actors !== 'N/A' ? data.Actors : null,
          country: data.Country !== 'N/A' ? data.Country : null,
          language: data.Language !== 'N/A' ? data.Language : null,
          awards: data.Awards !== 'N/A' ? data.Awards : null
        };
      }
      throw new Error('Movie not found');
    } catch (error) {
      console.error(`Error fetching movie details for ${id}:`, error);
      throw error;
    }
  },

  // Get movie-specific video content - FIXED TO GET CORRECT TRAILERS
  getMovieVideo(movieTitle, movieId) {
    console.log(`🎬 Getting video for movie ID: ${movieId}, Title: "${movieTitle}"`);
    
    // Comprehensive movie trailer database with ACTUAL trailer URLs
    const movieTrailers = {
      // Popular Movies
      'tt0111161': { // The Shawshank Redemption
        url: 'https://www.youtube.com/embed/NmzuHjWmXOc',
        title: 'The Shawshank Redemption - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/NmzuHjWmXOc/maxresdefault.jpg',
        description: 'Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.'
      },
      'tt0068646': { // The Godfather
        url: 'https://www.youtube.com/embed/UaVTIH8mujA',
        title: 'The Godfather - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/UaVTIH8mujA/maxresdefault.jpg',
        description: 'The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son.'
      },
      'tt0468569': { // The Dark Knight
        url: 'https://www.youtube.com/embed/EXeTwQWrcwY',
        title: 'The Dark Knight - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/EXeTwQWrcwY/maxresdefault.jpg',
        description: 'When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests.'
      },
      'tt0071562': { // The Godfather Part II
        url: 'https://www.youtube.com/embed/9O1Iy9mag_4',
        title: 'The Godfather Part II - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/9O1Iy9mag_4/maxresdefault.jpg',
        description: 'The early life and career of Vito Corleone in 1920s New York City is portrayed, while his son, Michael, expands and tightens his grip on the family crime syndicate.'
      },
      'tt0050083': { // 12 Angry Men
        url: 'https://www.youtube.com/embed/_13J_9B5jEk',
        title: '12 Angry Men - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/_13J_9B5jEk/maxresdefault.jpg',
        description: 'A jury holdout attempts to prevent a miscarriage of justice by forcing his colleagues to reconsider the evidence.'
      },
      'tt0108052': { // Schindler's List
        url: 'https://www.youtube.com/embed/gG22XNhtnoY',
        title: "Schindler's List - Official Trailer",
        thumbnail: 'https://img.youtube.com/vi/gG22XNhtnoY/maxresdefault.jpg',
        description: 'In German-occupied Poland during World War II, industrialist Oskar Schindler gradually becomes concerned for his Jewish workforce after witnessing their persecution by the Nazis.'
      },
      'tt0167260': { // The Lord of the Rings: The Return of the King
        url: 'https://www.youtube.com/embed/r5X-hFf6Bwo',
        title: 'The Lord of the Rings: The Return of the King - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/r5X-hFf6Bwo/maxresdefault.jpg',
        description: 'Gandalf and Aragorn lead the World of Men against Sauron\'s army to draw his gaze from Frodo and Sam as they approach Mount Doom with the One Ring.'
      },
      'tt0110912': { // Pulp Fiction
        url: 'https://www.youtube.com/embed/s7EdQ4FqbhY',
        title: 'Pulp Fiction - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/s7EdQ4FqbhY/maxresdefault.jpg',
        description: 'The lives of two mob hitmen, a boxer, a gangster and his wife, and a pair of diner bandits intertwine in four tales of violence and redemption.'
      },
      'tt0060196': { // The Good, the Bad and the Ugly
        url: 'https://www.youtube.com/embed/WCN5JJY_wiA',
        title: 'The Good, the Bad and the Ugly - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/WCN5JJY_wiA/maxresdefault.jpg',
        description: 'A bounty hunting scam joins two men in an uneasy alliance against a third in a race to find a fortune in gold buried in a remote cemetery.'
      },
      'tt0137523': { // Fight Club
        url: 'https://www.youtube.com/embed/qtRKdVHc-cE',
        title: 'Fight Club - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/qtRKdVHc-cE/maxresdefault.jpg',
        description: 'An insomniac office worker and a devil-may-care soap maker form an underground fight club that evolves into an anarchist organization.'
      },

      // Trending Movies
      'tt6751668': { // Parasite
        url: 'https://www.youtube.com/embed/5xH0HfJHsaY',
        title: 'Parasite - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/5xH0HfJHsaY/maxresdefault.jpg',
        description: 'A poor family schemes to become employed by a wealthy family and infiltrate their household by posing as unrelated, highly qualified individuals.'
      },
      'tt7286456': { // Joker
        url: 'https://www.youtube.com/embed/zAGVQLHvwOY',
        title: 'Joker - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/zAGVQLHvwOY/maxresdefault.jpg',
        description: 'A mentally troubled comedian is disregarded and mistreated by society. He then embarks on a downward spiral of revolution and bloody crime.'
      },
      'tt4154756': { // Avengers: Endgame
        url: 'https://www.youtube.com/embed/TcMBFSGVi1c',
        title: 'Avengers: Endgame - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/TcMBFSGVi1c/maxresdefault.jpg',
        description: 'After the devastating events of Infinity War, the Avengers assemble once more to reverse Thanos\' actions and restore balance to the universe.'
      },
      'tt1825683': { // Black Panther
        url: 'https://www.youtube.com/embed/xjDjIWPwcPU',
        title: 'Black Panther - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/xjDjIWPwcPU/maxresdefault.jpg',
        description: 'T\'Challa, heir to the hidden but advanced kingdom of Wakanda, must step forward to lead his people into a new future.'
      },
      'tt3896198': { // Guardians of the Galaxy Vol. 2
        url: 'https://www.youtube.com/embed/dW1BIid8Osg',
        title: 'Guardians of the Galaxy Vol. 2 - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/dW1BIid8Osg/maxresdefault.jpg',
        description: 'The Guardians struggle to keep together as a team while dealing with their personal family issues, notably Star-Lord\'s encounter with his father.'
      },
      'tt2250912': { // Spider-Man: Homecoming
        url: 'https://www.youtube.com/embed/39udgGPyYMg',
        title: 'Spider-Man: Homecoming - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/39udgGPyYMg/maxresdefault.jpg',
        description: 'Peter Parker balances his life as an ordinary high school student in Queens with his superhero alter-ego Spider-Man.'
      },
      'tt3501632': { // Thor: Ragnarok
        url: 'https://www.youtube.com/embed/ue80QwXMRHg',
        title: 'Thor: Ragnarok - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/ue80QwXMRHg/maxresdefault.jpg',
        description: 'Imprisoned on the planet Sakaar, Thor must race against time to return to Asgard and stop Ragnarök.'
      },
      'tt1211837': { // Doctor Strange
        url: 'https://www.youtube.com/embed/HSzx-zryEgM',
        title: 'Doctor Strange - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/HSzx-zryEgM/maxresdefault.jpg',
        description: 'While on a journey of physical and spiritual healing, a brilliant neurosurgeon is drawn into the world of the mystic arts.'
      },
      'tt3498820': { // Captain America: Civil War
        url: 'https://www.youtube.com/embed/dKrVegVI0Us',
        title: 'Captain America: Civil War - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/dKrVegVI0Us/maxresdefault.jpg',
        description: 'Political involvement in the Avengers\' affairs causes a rift between Captain America and Iron Man.'
      },
      'tt2395427': { // Avengers: Age of Ultron
        url: 'https://www.youtube.com/embed/tmeOjFno6Do',
        title: 'Avengers: Age of Ultron - Official Trailer',
        thumbnail: 'https://img.youtube.com/vi/tmeOjFno6Do/maxresdefault.jpg',
        description: 'When Tony Stark and Bruce Banner try to jump-start a dormant peacekeeping program called Ultron, things go horribly wrong.'
      }
    };

    // Get the specific trailer for this movie
    const trailer = movieTrailers[movieId];
    
    if (trailer) {
      console.log(`✅ Found specific trailer for ${movieTitle}: ${trailer.title}`);
      return {
        success: true,
        videoUrl: trailer.url,
        title: trailer.title,
        thumbnail: trailer.thumbnail,
        description: trailer.description,
        source: 'youtube_official'
      };
    } else {
      console.log(`⚠️ No specific trailer found for ${movieTitle} (${movieId}), using fallback`);
      // Fallback for movies not in our database
      return {
        success: true,
        videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        title: `${movieTitle} - Trailer`,
        thumbnail: 'https://images.unsplash.com/photo-1489599735734-79b4169c2a78?w=800&h=450&fit=crop',
        description: `Watch the trailer for ${movieTitle}.`,
        source: 'fallback_video'
      };
    }
  },

  // Get recommendations (we'll search for movies in the same genre)
  async getRecommendations(id) {
    try {
      const movie = await this.getMovieDetails(id);
      if (movie.genres && movie.genres.length > 0) {
        // Search for movies with similar genre
        const genre = movie.genres[0].name;
        const searchResults = await this.searchMovies(genre);
        // Filter out the current movie and return up to 10 recommendations
        const recommendations = searchResults.results
          .filter((rec) => rec.id !== id)
          .slice(0, 10);
        return { results: recommendations };
      }
    } catch (error) {
      console.error('Error getting recommendations:', error);
    }
    return { results: [] };
  },

  // Helper functions for image URLs (OMDb provides direct URLs)
  getImageUrl: (path) => {
    return path || '/placeholder-movie.jpg';
  },

  getBackdropUrl: (path) => {
    return path || '/placeholder-backdrop.jpg';
  }
};